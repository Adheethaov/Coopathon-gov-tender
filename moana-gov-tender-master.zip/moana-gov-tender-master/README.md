# scrape-gov-tender
Scrape and display various government tenders. Project prepared for ULCCS at Coopthon 2018
