from django.apps import AppConfig


class FirstConfig(AppConfig):
    name = 'first'
